# ETJ EtronJF8 規劃與 Skills 文件包

先讀 START-HERE.md。

- docs/PROJECT-PLAN.md
- docs/DECISIONS.md
- docs/WORKFLOW-RULES.md
- docs/ARCHITECTURE.md
- docs/UI-I18N-TIME.md
- docs/SECURITY-TESTING.md
- docs/ATTENDANCE-IMPORT.md
- AGENTS.md
- docs/TASKS.md
- docs/VERSION-CHECK.md
- START-HERE.md

## Skills
- project-bootstrap：驗證技術版本、建立單體專案骨架與工具鏈
- architecture-spec：維護架構規格、API 契約及任務邊界
- ui-i18n-time：建立天藍 UI、四語及東京台北時區
- auth-rbac：實作帳號、工作階段與物件層權限
- hr-master：建立人事主檔與假額帳本
- workflow-engine：建立版本化條件簽核與待辦
- leave-overtime：實作請假及加班垂直切片
- travel-settlement：實作出差、預支及結報
- expense-payment：實作報支、供應商及請款
- seal-contract：實作用印與合約版本
- attendance-import：實作可重跑的出勤匯入及查詢
- database-migration：管理 SQLite schema 與資料遷移
- security-audit：審查個資、附件、session 及稽核
- test-review：執行測試及獨立程式審查
- release-operations：建立部署、備份、回復與維運
